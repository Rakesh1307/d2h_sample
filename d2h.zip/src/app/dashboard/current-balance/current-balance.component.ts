import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-balance',
  templateUrl: './current-balance.component.html',
  styleUrls: ['./current-balance.component.css']
})
export class CurrentBalanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
